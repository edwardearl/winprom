// BrowseFormat_dlg.cpp : implementation file
//

#include "stdafx.h"
#include "winprom.h"
#include "BrowseFormat_dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CBrowseFormat_dlg dialog

CBrowseFormat_dlg::CBrowseFormat_dlg(bool r, CWnd* pParent /*=NULL*/)
  : CDialog(CBrowseFormat_dlg::IDD, pParent),reload(r)
{
  //{{AFX_DATA_INIT(CBrowseFormat_dlg)
  m_custom = _T("");
  m_size = -1;
  m_provider = -1;
  m_scale = -1;
  m_option = -1;
  //}}AFX_DATA_INIT
}

void CBrowseFormat_dlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CBrowseFormat_dlg)
  DDX_Control(pDX, IDC_RELOAD, m_reload_butn);
  DDX_Control(pDX, IDC_OPTION, m_option_ctl);
  DDX_Control(pDX, IDC_MAPSIZE, m_size_ctl);
  DDX_Control(pDX, IDC_SCALE, m_scale_ctl);
  DDX_Control(pDX, IDC_CUSTOM, m_custom_edit);
  DDX_Text(pDX, IDC_CUSTOM, m_custom);
  DDX_CBIndex(pDX, IDC_MAPSIZE, m_size);
  DDX_CBIndex(pDX, IDC_PROVIDER, m_provider);
  DDX_CBIndex(pDX, IDC_SCALE, m_scale);
  DDX_CBIndex(pDX, IDC_OPTION, m_option);
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBrowseFormat_dlg, CDialog)
  //{{AFX_MSG_MAP(CBrowseFormat_dlg)
  ON_BN_CLICKED(IDC_RESET, OnReset)
  ON_BN_CLICKED(IDC_RELOAD, OnReload)
  ON_CBN_SELCHANGE(IDC_PROVIDER, OnChangeProvider)
  ON_CBN_SELCHANGE(IDC_OPTION, OnChangeOption)
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CBrowseFormat_dlg message handlers

static const char *topo="Topographic map",*photo="Overhead photo",
  *street="Street map",*hybrid="Hybrid",*terrain="Terrain";

static const Scale_info power2_scales[] = {
  {1,"�m/pixel"},
  {2,"�m/pixel"},
  {3,"1m/pixel"},
  {7,"2m/pixel"},
  {13,"4m/pixel"},
  {26,"8m/pixel"},
  {52,"16m/pixel"},
  {105,"32m/pixel"},
  {210,"64m/pixel"},
  {420,"128m/pixel"},
  {840,"256m/pixel"},
  {1680,"512m/pixel"},
  {3360,"1km/pixel"},
  {6719,"2km/pixel"},
  {13438,"4km/pixel"},
  {26877,"8km/pixel"},
  {53753,"16km/pixel"},
  {107507,"33km/pixel"},
  {215013,"65km/pixel"},
  {0,0}
};

static const Option_info acme_options[] = {
  {power2_scales+2,topo,0},
  {power2_scales,photo,0},
  {power2_scales+2,street,0},
  {power2_scales,hybrid,0},
  {power2_scales+4,terrain,0},
  {power2_scales+1,"DOQ",0},
  {power2_scales+1,"Mapnik",0},
  {0,0,0}
};

static const Scale_info topoquest_scales[] = {
  {13,"4m/pixel"},
  {26,"8m/pixel"},
  {52,"16m/pixel"},
  {105,"32m/pixel"},
  {210,"64m/pixel"},
  {420,"128m/pixel"},
  {840,"256m/pixel"},
  {1680,"512m/pixel"},
  {3360,"1km/pixel"},
  {6719,"2km/pixel"},
  {13438,"4km/pixel"},
  {33600,"10km/pixel"},
  {0,0}
};
static const Option_info topoquest_options[] = {
  {topoquest_scales,topo,3},
  {0,0,0}
};

static const Option_info mytopo_options[] = {
  {power2_scales,street,0},
  {0,0,0}
};

static const Scale_info topozone_scales[] = {
  {3,"1:10,000"},
  {8,"1:24,000"},
  {8,"1:25,000"},
  {17,"1:50,000"},
  {21,"1:63,360"},
  {33,"1:100,000"},
  {67,"1:200,000"},
  {83,"1:250,000"},
  {167,"1:500,000"},
  {333,"1:1,000,000"},
  {0,0}
};
static const Option_info topozone_options[] = {
  {topozone_scales,topo,3},
  {0,0,0}
};

static const Scale_info esri_scales[] = {
  {24,"1:24,000"},
  {100,"1:100,000"},
  {250,"1:250,000"},
  {0,0}
};
static const Option_info esri_options[] = {
  {esri_scales,topo,0},
  {0,0,0}
};

static const Scale_info terra_scales[] = {
  {3,"1m/pixel"}, // 10
  {7,"2m/pixel"}, // 11
  {13,"4m/pixel"},
  {26,"8m/pixel"},
  {52,"16m/pixel"},
  {105,"32m/pixel"},
  {210,"64m/pixel"},
  {420,"128m/pixel"},
  {840,"256m/pixel"},
  {1680,"512m/pixel"},
  {0,0}
};
static const Option_info terra_options[] = {
  {terra_scales+1,topo,3}, // Terraserver topo does not have 1m/pixel
  {terra_scales,photo,3},
  {0,0,0}
};

static const Scale_info mapquest_street_scales[] = {
  {7,"1:8,200"},
  {16,"1:19,000"},
  {35,"1:41,000"},
  {88,"1:106,000"},
  {391,"1:470,000"},
  {1200,"1:1,440,000"},
  {3406,"1:4,100,000"},
  {9262,"1:11,000,000"},
  {29334,"1:35,000,000"},
  {86558,"1:104,000,000"},
  {0,0}
};
static const Scale_info mapquest_photo_scales[] = {
  {6,"1:6,800"},
  {8,"1:10,000"},
  {13,"1:16,000"},
  {31,"1:38,000"},
  {69,"1:83,000"},
  {96,"1:115,000"},
  {430,"1:520,000"},
  {869,"1:1,040,000"},
  {3517,"1:4,200,000"},
  {10089,"1:12,000,000"},
  {29469,"1:35,000,000"},
  {88737,"1:106,000,000"},
  {0,0}
};
static const Option_info mapquest_options[] = {
  {mapquest_street_scales,street,2},
  {mapquest_photo_scales,photo,2},
  {0,0,0}
};

static const Scale_info maptech_nautical_scales[] = {
  {21,"1:40,000"},
  {42,"1:80,000"},
  {129,"1:247,482"},
  {312,"1:600,000"},
  {352,"1:675,000"},
  {452,"1:868,003"},
  {752,"1:1,444,000"},
  {859,"1:1,650,000"},
  {9227,"1:17,716,535"},
  {0,0}
};
static const Scale_info maptech_topo_scales[] = {
  {12,"1:24,000"},
  {52,"1:100,000"},
  {130,"1:250,000"},
  {0,0}
};
static const Scale_info maptech_aero_scales[] = {
  {130,"Class B"},
  {260,"Sectional"},
  {521,"WAC"},
  {0,0}
};
static const Option_info maptech_options[] = {
  {maptech_nautical_scales,"Nautical chart",0},
  {maptech_topo_scales,topo,0},
  {maptech_aero_scales,"Aeronautical chart",0},
  {0,0,0}
};

static const Scale_info mappoint_scales[] = {
  {2,"0.5 km"},
  {7,"1.5 km"},
  {15,"3 km"},
  {30,"6 km"},
  {60,"12 km"},
  {125,"25 km"},
  {375,"75 km"},
  {2000,"400 km"},
  {5000,"1000 km"},
  {17500,"3500 km"},
  {30000,"6000 km"},
  {0,0}
};
static const Scale_info mappoint_world_scales[] = {
  {375,"75 km"},
  {625,"125 km"},
  {1250,"250 km"},
  {2500,"500 km"},
  {6250,"1250 km"},
  {12500,"2500 km"},
  {20000,"4000 km"},
  {27500,"5500 km"},
  {37500,"7500 km"},
  {50000,"10000 km"},
  {75000,"15000 km"},
  {0,0}
};
static const Option_info mappoint_options[] = {
  {mappoint_scales,"North America",0},
  {mappoint_scales,"Europe",0},
  {mappoint_world_scales,"World",0},
  {0,0,0}
};

static const Scale_info offroute_scales[] = {
  {163,"10 miles"},
  {327,"20 miles"},
  {654,"40 miles"},
  {1308,"80 miles"},
  {2615,"160 miles"},
  {5231,"320 miles"},
  {10462,"640 miles"},
  {20924,"1280 miles"},
  {0,0}
};
static const Option_info offroute_options[] = {
  {offroute_scales,topo,0},
  {0,0,0}
};

static const Option_info google_options[] = {
  {power2_scales,street,0},
  {power2_scales+4,terrain,0}, // terrain view does not zoom larger than 4m/pixel
  {power2_scales,photo,0},
  {power2_scales,hybrid,0},
  {0,0,0}
};

static const Option_info yahoo_options[] = {
  {power2_scales+2,street,0},
  {power2_scales+2,photo,0},
  {power2_scales+2,hybrid,0},
  {0,0,0}
};

static const Scale_info usgs_gnis_scale[] = {
  {420,"128m/pixel"},
  {0,0}
};
static const Option_info usgs_gnis_options[] = {
  {usgs_gnis_scale,street,0},
  {0,0,0}
};

static const Option_info ve_options[] = {
  {power2_scales,street,0},
  {power2_scales,photo,0},
  {power2_scales,hybrid,0},
  {0,0,0}
};

static const Scale_info fe_scales[] = {
  {8,"2.4m/pixel"},
  {16,"5m/pixel"},
  {33,"10m/pixel"},
  {69,"21m/pixel"},
  {141,"43m/pixel"},
  {289,"88m/pixel"},
  {593,"181m/pixel"},
  {1217,"371m/pixel"},
  {0,0}
};
static const Option_info fe_options[] = {
  {fe_scales,"Google",0},
  {fe_scales,"Virtualearth photo",0},
  {fe_scales,"Virtualearth labels",0},
  {fe_scales,"Yahoo",0},
  {fe_scales,"Ask.com photo",0},
  {fe_scales,"Ask.com physical",0},
  {fe_scales,"OpenLayers",0},
  {fe_scales,"NASA Terra",0},
  {0,0,0}
};
static const Option_info pb_options[] = {
  {0,"Radius search",0},
  {0,"Elevation ladder",0},
  {0,"Prominence ladder",0},
  {0,0,0}
};

static Provider_info providers[] = {
  {acme_options},
  {topoquest_options},
  {mytopo_options},
  {topozone_options},
  {esri_options},
  {terra_options},
  {mapquest_options},
  {maptech_options},
  {mappoint_options},
  {offroute_options},
  {google_options},
  {yahoo_options},
  {usgs_gnis_options},
  {ve_options},
  {fe_options},
  {pb_options}
};


void CBrowseFormat_dlg::OnReset()
{
  UpdateData();
  CPromApp::set_browse_format(m_provider,m_option,m_scale,m_size);
  m_custom_edit.SetWindowText(CPromDoc::buf);
}


void CBrowseFormat_dlg::set_option_list()
{
  const Provider_info& pi=providers[m_provider];
  while (m_option_ctl.GetCount()>0) m_option_ctl.DeleteString(0);
  for (unsigned i=0; pi.options[i].text; ++i)
    m_option_ctl.AddString(pi.options[i].text);
  m_option_ctl.SetCurSel(m_option);

  set_scale_size_list();
}

void CBrowseFormat_dlg::set_scale_size_list()
{
  const Option_info& opt=providers[m_provider].options[m_option];

  while (m_scale_ctl.GetCount()>0) m_scale_ctl.DeleteString(0);
  if (opt.scales) {
    for (int i=0; opt.scales[i].text; ++i)
      m_scale_ctl.AddString(opt.scales[i].text);
    m_scale_ctl.SetCurSel(m_scale);
  }
  m_scale_ctl.EnableWindow(opt.scales!=0);

  while (m_size_ctl.GetCount()>0) m_size_ctl.DeleteString(0);
  if (opt.nsize>=2) m_size_ctl.AddString("Small");
  if (opt.nsize>=3) m_size_ctl.AddString("Medium");
  if (opt.nsize>=2) m_size_ctl.AddString("Large");
  if (opt.nsize>0) m_size_ctl.SetCurSel(m_size);
  m_size_ctl.EnableWindow(opt.nsize>0);
}

BOOL CBrowseFormat_dlg::OnInitDialog()
{
  CPromApp *app=CPromApp::getApp();
  m_provider=app->browse_provider;
  m_option=app->browse_option;
  m_size=app->browse_size;
  old_size=app->old_size;
  m_scale=app->browse_scale;
  old_scale=app->old_scale;
  m_custom=app->custm_format;

  CDialog::OnInitDialog();

  if (!reload) m_reload_butn.EnableWindow(FALSE);
  set_option_list();

  return TRUE;
}

void CBrowseFormat_dlg::update_close(UINT rID)
{
  if (!UpdateData()) return;

  const char *custm=m_custom;
  for (const char *fc=custm; *fc; ++fc) {
    if (*fc=='%') {
      switch (*++fc) {
      case 'A': case 'a':
      case 'O': case 'o':
      case 'Z': case 'z':
      case 'N': case 'n':
      case 'E': case 'e':
      case '%':
	break;
      default:
	MessageBox("An invalid character appears after \"%\" in the custom format.\n"
		   "Valid format strings are %A, %O, %Z, %N, %E, and %%.",
		   "Winprom Location Format Error",MB_OK|MB_ICONERROR);
	m_custom_edit.SetFocus();
	m_custom_edit.SetSel(fc-custm,fc-custm+1);
	return;
      }
    }
  }

  CPromApp *app=CPromApp::getApp();
  app->browse_provider=m_provider;
  app->browse_option=m_option;
  app->browse_size=m_size;
  app->old_size=old_size;
  app->browse_scale=m_scale;
  app->old_scale=old_scale;
  app->custm_format=m_custom;

  CDialog::EndDialog(rID);
}

void CBrowseFormat_dlg::OnOK()
{
  update_close(IDOK);
}

void CBrowseFormat_dlg::OnReload()
{
  update_close(IDC_RELOAD);
}

void CBrowseFormat_dlg::set_best_size(int nsize)
{
  if (nsize==3) m_size=old_size;
  else if (nsize==2) m_size=old_size/2;
  else assert(nsize==0);
}

void CBrowseFormat_dlg::set_best_scale(const Scale_info scales[])
{
  if (scales) {
    float scale_ratio,best_ratio=0;
    for (int i=0; scales[i].scale>0; ++i) {
      scale_ratio=scales[i].scale/old_scale;
      if (scale_ratio>1) scale_ratio=1/scale_ratio;
      if (scale_ratio>best_ratio) {
	best_ratio=scale_ratio;
	m_scale=i;
      }
    }
  }
}

void CBrowseFormat_dlg::update_option(const Option_info& old_opt,
				      const Option_info& new_opt)
{
  // change the scale to reflect new option
  if (old_opt.scales) old_scale=old_opt.scales[m_scale].scale;
  set_best_scale(new_opt.scales);

  // change the size to reflect new option
  if (old_opt.nsize==3) old_size=m_size;
  else if (old_opt.nsize==2) old_size=m_size*2;
  set_best_size(new_opt.nsize);
}

void CBrowseFormat_dlg::OnChangeOption()
{
  int old_option=m_option;
  UpdateData();
  const Provider_info &prov=providers[m_provider];
  update_option(prov.options[old_option],prov.options[m_option]);
  set_scale_size_list();
}

void CBrowseFormat_dlg::OnChangeProvider()
{
  int old_provider=m_provider,new_option;
  UpdateData();
  assert(m_provider<sizeof providers/sizeof(Provider_info));
  Provider_info &new_prov=providers[m_provider],
    &old_prov=providers[old_provider];
  new_option=new_prov.last_option;
  old_prov.last_option=m_option;
  m_option_ctl.SetCurSel(new_option);
  update_option(old_prov.options[m_option],new_prov.options[new_option]);
  m_option=new_option;
  set_option_list();
}
