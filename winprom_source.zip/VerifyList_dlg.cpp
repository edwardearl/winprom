// VerifyList_dlg.cpp : implementation file
//

#include "stdafx.h"
#include "crypt.h"
#include "VerifyList_dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CVerifyList_dlg dialog

CVerifyList_dlg::CVerifyList_dlg(const CArray<bool,bool>& ra, const CStringArray& pa,
				 CWnd *pParent /*=NULL*/)
  : CDialog(CVerifyList_dlg::IDD, pParent),results(ra),paths(pa)
{
  //{{AFX_DATA_INIT(CVerifyList_dlg)
    // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}


void CVerifyList_dlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CVerifyList_dlg)
  DDX_Control(pDX, IDC_VERIFY_STATUS, m_list);
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CVerifyList_dlg, CDialog)
  //{{AFX_MSG_MAP(CVerifyList_dlg)
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CVerifyList_dlg message handlers

BOOL CVerifyList_dlg::OnInitDialog() 
{
  CDialog::OnInitDialog();

  CCryptApp *app=(CCryptApp *)AfxGetApp();
  m_list.SetImageList(&app->smallImageList,LVSIL_SMALL);
  TRACE("%d\n",app->smallImageList.GetImageCount());
  for (int i=0; i<paths.GetSize(); ++i)
    m_list.InsertItem(i,paths[i],(int)results[i]);

  return TRUE;  // return TRUE unless you set the focus to a control
		// EXCEPTION: OCX Property Pages should return FALSE
}
