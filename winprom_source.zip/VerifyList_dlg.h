#if !defined(AFX_VERIFYLIST_DLG_H__F9082B21_B0BC_11D5_A238_10C843C10000__INCLUDED_)
#define AFX_VERIFYLIST_DLG_H__F9082B21_B0BC_11D5_A238_10C843C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VerifyList_dlg.h : header file
//

#include <afxtempl.h>

/////////////////////////////////////////////////////////////////////////////
// CVerifyList_dlg dialog

class CVerifyList_dlg : public CDialog
{
  const CArray<bool,bool>& results;
  const CStringArray& paths;

// Construction
public:
  CVerifyList_dlg(const CArray<bool,bool>&, const CStringArray&, CWnd *pParent=NULL);   // standard constructor

// Dialog Data
  //{{AFX_DATA(CVerifyList_dlg)
  enum { IDD = IDD_VERIFY_LIST };
  CListCtrl	m_list;
  //}}AFX_DATA


// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CVerifyList_dlg)
  protected:
  virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
  //}}AFX_VIRTUAL

// Implementation
protected:

  // Generated message map functions
  //{{AFX_MSG(CVerifyList_dlg)
  virtual BOOL OnInitDialog();
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VERIFYLIST_DLG_H__F9082B21_B0BC_11D5_A238_10C843C10000__INCLUDED_)
