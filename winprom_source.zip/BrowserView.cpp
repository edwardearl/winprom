// BrowserView.cpp : implementation file
//

#include "stdafx.h"
#include "winprom.h"
#include "BrowserView.h"
#include "PromDoc.h"
#include "BrowseFormat_dlg.h"
#include "BrowserFrame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CBrowserView

IMPLEMENT_DYNCREATE(CBrowserView, CHtmlView)

CBrowserView::CBrowserView()
{
  //{{AFX_DATA_INIT(CBrowserView)
    // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
  target=0;
  title_format.name_f=Feature_fmt::ALT_LOC;
  title_format.show_elev=title_format.show_loc=false;
}

CBrowserView::~CBrowserView()
{
  if (GetDocument()->browser_view==this)
    GetDocument()->browser_view=0;
}

void CBrowserView::set_format(int provider, int option, int scale, int size)
{
  static const char
    *topozone_size[] = {"s","m","l"},
    *topozone_scale[] = {"12","24","25","50","63.360","100","200","250","500","1000"},
    *mapquest_size[] = {"","&size=big"},
    *mappoint_layer[] = {"USA0409","EUR0809","WLD0409"},
    *google_type[] = {"","&t=k","&t=h"},
    *fe_provider[] = {"ggl","msa","msl","yh","aska","askp","ol","nasa"};
  static const char ve_style[] = {'r','a','h'};
  static const int
    topozone_layer[] = {25,25,25,25,50,100,100,250,250,250},
    maptech_scale[][10] = {{40000,80000,247482,600000,675000,868003,1444000,1650000,17716535},
			   {24000,100000,250000},
			   {250000,500000,1000000}},
    mappoint_scale[][11] = {{1,3,6,12,25,50,150,800,2000,7000,12000},
			    {1,3,6,12,25,50,150,800,2000,7000,12000},
			    {150,250,500,1000,2500,5000,8000,11000,15000,20000,30000}},
    offroute_scale[] = {10,20,40,80,160,320,640,1280};
  switch (provider) {
  case 0: // Topozone
    sprintf(CPromDoc::buf,
	    "http://www.topozone.com/map.asp?lat=%%A&lon=%%O&s=%s&layer=DRG%d&size=%s",
	    topozone_scale[scale],topozone_layer[scale],topozone_size[size]);
    break;
  case 1: // ESRI
    sprintf(CPromDoc::buf,
	    "http://arcdata.esri.com/data_downloader/DataDownloader_SM?part=89173&mapScale=%d&cx=%%O&cy=%%A",
	    scale+1);
    break;
  case 2: // Terraserver
    sprintf(CPromDoc::buf,
	    "http://terraserver.homeadvisor.msn.com/image.aspx?t=%d&s=%d&Lon=%%O&Lat=%%A&w=%d",
	    2-option,11+scale-option,size);
    break;
  case 3: // MapQuest
    sprintf(CPromDoc::buf,
	    "http://www.mapquest.com/maps/map.adp?latlongtype=decimal&latitude=%%A&longitude=%%O&zoom=%d%s%s",
	    (9+option*2)-scale,option?"&dtype=a":"",mapquest_size[size]);
    break;
  case 4: // MapTech
    sprintf(CPromDoc::buf,
	    "http://mapserver.maptech.com/homepage/index.cfm?lat=%%A&lon=%%O&scale=%d&zoom=100&type=%d",
	    maptech_scale[option][scale],option);
    break;
  case 5: // MS MapPoint
    sprintf(CPromDoc::buf,
	    "http://mappoint.msn.com/(d0nnqb20s2jlgh55s21xij55)/map.aspx?C=%%A,%%O&A=%d&L=%s",
	    mappoint_scale[option][scale],mappoint_layer[option]);
    break;
  case 6: // Offroute
    sprintf(CPromDoc::buf,
	    "http://offroute.com/geofinder/fs_geographic-finder.asp?lat=%%A&lon=%%O&zoom=%d",
	    offroute_scale[scale]);
    break;
  case 7: // Google
    sprintf(CPromDoc::buf,
	    "http://maps.google.com/maps?q=%%A+%%O%s&z=%d",
	    google_type[option],scale);
    break;
  case 8: // Virtual Earth
    sprintf(CPromDoc::buf,
	    "http://virtualearth.msn.com/default.aspx?v=1&cp=%%A|%%O&lvl=%d&style=%c",
	    19-scale,ve_style[option]);
    break;
  case 9: // Flashearth
    sprintf(CPromDoc::buf,
	    "http://www.flashearth.com/?lat=%%A&lon=%%O&z=%d&r=0&src=%s",
	    16-scale,fe_provider[option]);
    break;
  }
}

void CBrowserView::Navigate(const GridPoint& loc)
{
  CPromApp *app=(CPromApp *)AfxGetApp();
  static char url_buf[256];
  GridPoint::real_format="%.4f";
  GridPoint::angle_format=AF_DEGREE;
  if (app->custm_format.IsEmpty()) {
    set_format(app->browse_provider,app->browse_option,
	       app->browse_scale,app->browse_size);
    GridPoint::format=CPromDoc::buf;
  }
  else GridPoint::format=app->custm_format;
  loc.sprint(url_buf);
  location=loc;
  TRACE("Navigating to %s\n",url_buf);
  CHtmlView::Navigate(url_buf);
}

void CBrowserView::Navigate(Feature& tgt, FT_index type)
{
  target=&tgt;
  target_type=type;
  Navigate(tgt.location);
}


BEGIN_MESSAGE_MAP(CBrowserView, CHtmlView)
  //{{AFX_MSG_MAP(CBrowserView)
  ON_COMMAND(ID_GO_RELOAD, OnGoReload)
  ON_COMMAND(ID_GO_BACK, OnGoBack)
  ON_COMMAND(ID_GO_FORWARD, OnGoForward)
  ON_COMMAND(ID_VIEW_FEATURE, OnViewFeature)
  ON_COMMAND(ID_GO_STOP, OnGoStop)
  ON_UPDATE_COMMAND_UI(ID_GO_STOP, OnUpdateGoStop)
  ON_COMMAND(ID_OPTIONS_TITLE, OnOptionsTitle)
  ON_COMMAND(ID_OPTIONS_URL, OnOptionsURL)
  ON_COMMAND(ID_OPTIONS_OFFLINE, OnOptionsOffline)
  ON_UPDATE_COMMAND_UI(ID_OPTIONS_OFFLINE, OnUpdateOptionsOffline)
  //}}AFX_MSG_MAP
  // Standard printing commands
  ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
  ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CBrowserView diagnostics

#ifdef _DEBUG
void CBrowserView::AssertValid() const
{
  CHtmlView::AssertValid();
}

void CBrowserView::Dump(CDumpContext& dc) const
{
  CHtmlView::Dump(dc);
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CBrowserView message handlers

void CBrowserView::OnOptionsTitle()
{
  CFeatureFmt_dlg dlg(GetDocument()->data,this,title_format);
  if (dlg.DoModal()!=IDOK) return;
  SetViewTitle();
}

void CBrowserView::SetViewTitle()
{
  title_format.set(GetDocument()->data,FMS_NOFLAG);
  if (target) target->sprint(CPromDoc::buf);
  else location.sprint(CPromDoc::buf);
  GetParent()->SetWindowText(CPromDoc::buf);
}

void CBrowserView::OnOptionsURL()
{
  if (CBrowseFormat_dlg(*this).DoModal()==IDC_RELOAD) {
    if (target) Navigate(*target,target_type);
    else Navigate(location);
  }
}

void CBrowserView::OnGoReload()
{
  Refresh();
}

void CBrowserView::OnGoBack()
{
  GoBack();
}

void CBrowserView::OnGoForward()
{
  GoForward();
}

void CBrowserView::OnViewFeature()
{
  CPromApp *app=((CPromApp *)AfxGetApp());
  if (target) app->viewFeature(GetDocument(),*target,target_type);
  else app->viewLocation(location);
}

void CBrowserView::OnGoStop()
{
  Stop();
}

void CBrowserView::OnUpdateGoStop(CCmdUI *pCmdUI)
{
  pCmdUI->Enable(GetBusy());
}

void CBrowserView::OnNavigateComplete2(LPCTSTR strURL)
{
  SetViewTitle();
  ((CBrowserFrame *)GetParent())->addressbar.SetDlgItemText(IDC_ADDRESS,strURL);
  CHtmlView::OnNavigateComplete2(strURL);
  url=strURL;
  TRACE("Navigation complete to %s\n",strURL);
}

void CBrowserView::OnOptionsOffline()
{
  SetOffline(!GetOffline());
}

void CBrowserView::OnUpdateOptionsOffline(CCmdUI *pCmdUI)
{
  pCmdUI->SetCheck(GetOffline());
}

void CBrowserView::OnUpdate(CView *, LPARAM lHint, CObject *pHint)
{
  Feature *changed_feature=(Feature *)lHint;
  if (changed_feature==0) {
    if (target) {
      target=0;
      SetViewTitle();
    }
  }
  else {
    if (target &&
	(changed_feature==&CPromDoc::dummyModifyAll ||
	 changed_feature==target))
      SetViewTitle();
  }
}

BOOL CBrowserView::OnPreparePrinting(CPrintInfo *pInfo)
{
  return DoPreparePrinting(pInfo);
  //return CHtmlView::OnPreparePrinting(pInfo);
}
