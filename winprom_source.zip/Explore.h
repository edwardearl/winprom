#ifndef _EXPLORE_
#define _EXPLORE_

#include <vector>
using std::vector;


botch; //cause an error in anything that includes this

template <class Nbr_iter>
class Explorer {
  vector<Nbr_iter> path;
  void operator++(int);
  Explorer(const Explorer&);
  Nbr_iter *tail;
  bool fwd;
  void push(const Nbr_iter& ni) {path.push_back(ni); tail=&path.back();}
  void push() {push(Nbr_iter(tail));}
  void pop() {path.pop_back(); tail=path.empty()?0:&path.back(); fwd=false;}
public:
  bool stop_on_return;
  Explorer() {tail=0; fwd=false; stop_on_return=true;}
  Explorer(const Nbr_iter& ni) {reset(ni); stop_on_return=true;}
  void operator++();
  Nbr_iter& operator*() const {return *tail;}
  operator bool() const {return tail!=0;}
  bool forward() const {return fwd;}
  void stop() {fwd=false;}
  void reset(const Nbr_iter&);
  void clear() {path.empty(); tail=0; fwd=false;}
};

template <class Nbr_iter>
void Explorer<Nbr_iter>::operator++()
{
  do {
    if (fwd) {
      push();
    }
    else {
      ++*tail;
      fwd=true;
    }
    if (!*tail) {
      pop();
    }
  } while (tail && !fwd && !stop_on_return);
}

template <class Nbr_iter>
void Explorer<Nbr_iter>::reset(const Nbr_iter& ni)
{
  path.empty();
  fwd=true;
  push(ni);
  if (!*tail) pop();
}


#endif // ndef _EXPLORE_
