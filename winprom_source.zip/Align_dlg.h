#if !defined(AFX_ALIGN_DLG_H__5F842D27_28BD_46AD_8233_6F60DCA95319__INCLUDED_)
#define AFX_ALIGN_DLG_H__5F842D27_28BD_46AD_8233_6F60DCA95319__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Align_dlg.h : header file
//


struct Align_info {
  enum Peak_map {PK_MAP_NONE,PK_MAP_DOMAIN,PK_MAP_ELEV} peak_map;
  enum Peak_geo {PK_GEO_NONE,PK_GEO_ELEV,PK_GEO_PROM,PK_GEO_DIST} peak_geo;
  enum Saddle {SADL_NONE,SADL_PROM,SADL_NOTCH,SADL_DIST,SADL_TOPO} saddle;
  float pk_radius,sadl_radius;
  bool bs_align;
};


/////////////////////////////////////////////////////////////////////////////
// CAlign_dlg dialog

class CAlign_dlg : public CDialog
{
  Align_info& target;
// Construction
public:
  CAlign_dlg(Align_info&, bool, bool, bool, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
  //{{AFX_DATA(CAlign_dlg)
  enum { IDD = IDD_ALIGN };
  int	m_peak_geo;
  int	m_peak_map;
  int	m_saddle;
  BOOL	m_bs_align;
  float	m_pk_radius;
  float	m_sadl_radius;
  //}}AFX_DATA
  bool have_elev,have_dom,have_topo;

// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CAlign_dlg)
  protected:
  virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
  //}}AFX_VIRTUAL

// Implementation
protected:

  // Generated message map functions
  //{{AFX_MSG(CAlign_dlg)
  virtual BOOL OnInitDialog();
  virtual void OnOK();
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALIGN_DLG_H__5F842D27_28BD_46AD_8233_6F60DCA95319__INCLUDED_)
