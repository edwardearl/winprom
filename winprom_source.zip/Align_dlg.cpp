// Align_dlg.cpp : implementation file
//

#include "stdafx.h"
#include "winprom.h"
#include "Align_dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAlign_dlg dialog

CAlign_dlg::CAlign_dlg(Align_info& tgt, bool e, bool d, bool t, CWnd* pParent /*=NULL*/)
  : CDialog(CAlign_dlg::IDD, pParent),target(tgt),
    have_elev(e),have_dom(d),have_topo(t)
{
  //{{AFX_DATA_INIT(CAlign_dlg)
  m_peak_geo = -1;
  m_peak_map = -1;
  m_saddle = -1;
  m_bs_align = FALSE;
  m_pk_radius = 0.0f;
  m_sadl_radius = 0.0f;
  //}}AFX_DATA_INIT
}

void CAlign_dlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CAlign_dlg)
  DDX_Radio(pDX, IDC_PK_NONE_GEO, m_peak_geo);
  DDX_Radio(pDX, IDC_PK_NONE_MAP, m_peak_map);
  DDX_Radio(pDX, IDC_SADL_NONE, m_saddle);
  DDX_Check(pDX, IDC_BS_ALIGN, m_bs_align);
  DDX_Text(pDX, IDC_PK_RADIUS, m_pk_radius);
  DDX_Text(pDX, IDC_SADL_RADIUS, m_sadl_radius);
  //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAlign_dlg, CDialog)
  //{{AFX_MSG_MAP(CAlign_dlg)
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CAlign_dlg message handlers

BOOL CAlign_dlg::OnInitDialog()
{
  m_pk_radius=target.pk_radius;
  m_peak_geo=target.peak_geo;
  m_peak_map=target.peak_map;
  m_sadl_radius=target.sadl_radius;
  m_saddle=target.saddle;
  m_bs_align=target.bs_align;

  CDialog::OnInitDialog();

  if (!have_dom) GetDlgItem(IDC_PK_DOMAIN)->EnableWindow(FALSE);
  if (!have_elev) GetDlgItem(IDC_PK_WALKUP)->EnableWindow(FALSE);
  if (!have_topo) GetDlgItem(IDC_SADL_TOPO)->EnableWindow(FALSE);

  return TRUE;  // return TRUE unless you set the focus to a control
}

void CAlign_dlg::OnOK()
{
  UpdateData();
  if (m_pk_radius<0 || m_sadl_radius<0) return;

  target.pk_radius=m_pk_radius;
  target.peak_geo=(Align_info::Peak_geo)m_peak_geo;
  target.peak_map=(Align_info::Peak_map)m_peak_map;
  target.sadl_radius=m_sadl_radius;
  target.saddle=(Align_info::Saddle)m_saddle;
  target.bs_align=m_bs_align!=FALSE;

  EndDialog(IDOK);
}
