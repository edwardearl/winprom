// BrowserFrame.cpp : implementation file
//

#include "stdafx.h"
#include "winprom.h"
#include "BrowserFrame.h"
#include "BrowserView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CBrowserFrame

IMPLEMENT_DYNCREATE(CBrowserFrame, CFrameWnd)

CBrowserFrame::CBrowserFrame()
{
}

CBrowserFrame::~CBrowserFrame()
{
}


BEGIN_MESSAGE_MAP(CBrowserFrame, CFrameWnd)
  //{{AFX_MSG_MAP(CBrowserFrame)
  ON_WM_CREATE()
  ON_COMMAND(ID_VIEW_ADDRESSBAR, OnViewAddressBar)
  ON_UPDATE_COMMAND_UI(ID_VIEW_ADDRESSBAR, OnUpdateViewAddressBar)
  //}}AFX_MSG_MAP
  ON_COMMAND(ID_CONTEXT_HELP, CFrameWnd::OnContextHelp)
  ON_COMMAND(IDC_GO, OnGo)
  ON_COMMAND(IDC_RESET, OnReset)
END_MESSAGE_MAP()


static UINT indicators[] =
{
  ID_SEPARATOR,           // status line indicator
  ID_INDICATOR_CAPS,
};

/////////////////////////////////////////////////////////////////////////////
// CBrowserFrame message handlers

int CBrowserFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
  if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
    return -1;
  if (!toolbar.Create(this) || !toolbar.LoadToolBar(IDR_BROWSER)) {
    TRACE0("Failed to create toolbar\n");
    return -1;  // fail to create
  }
  toolbar.SetBarStyle(toolbar.GetBarStyle() |
    CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

  if (!statusbar.Create(this) ||
      !statusbar.SetIndicators(indicators,sizeof(indicators)/sizeof(UINT))) {
    TRACE0("Failed to create status bar\n");
    return -1;  // fail to create
  }

  if (!addressbar.Create(this,IDD_ADDRESS,CBRS_BOTTOM|CBRS_TOP,0)) {
    TRACE0("Failed to create address bar\n");
    return -1;  // fail to create
  }
  addressbar.EnableDocking(CBRS_ALIGN_BOTTOM|CBRS_ALIGN_TOP);
  EnableDocking(CBRS_ALIGN_ANY);
  addressbar.SetWindowText("URL address");
  DockControlBar(&addressbar,AFX_IDW_DOCKBAR_TOP);

  return 0;
}

void CBrowserFrame::OnUpdateFrameTitle(BOOL)
{
  ((CBrowserView *)GetActiveView())->SetViewTitle();
}

void CBrowserFrame::OnViewAddressBar()
{
  bool displayed=!(addressbar.GetStyle()&WS_VISIBLE);
  ShowControlBar(&addressbar,displayed,FALSE);
}

void CBrowserFrame::OnUpdateViewAddressBar(CCmdUI *pCmdUI)
{
  pCmdUI->SetCheck(addressbar.GetStyle()&WS_VISIBLE);
}

void CBrowserFrame::OnGo()
{
  CString url;
  addressbar.GetDlgItemText(IDC_ADDRESS,url);
  ((CHtmlView *)GetActiveView())->Navigate(url);
}

void CBrowserFrame::OnReset()
{
  addressbar.SetDlgItemText(IDC_ADDRESS,((CBrowserView *)GetActiveView())->url);
}
