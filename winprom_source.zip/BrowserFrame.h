#if !defined(AFX_BROWSERFRAME_H__5D9F554B_2AFB_11D7_A23A_E0F653C10000__INCLUDED_)
#define AFX_BROWSERFRAME_H__5D9F554B_2AFB_11D7_A23A_E0F653C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BrowserFrame.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CBrowserFrame frame

class CBrowserFrame : public CFrameWnd
{
  DECLARE_DYNCREATE(CBrowserFrame)
protected:
  CBrowserFrame();           // protected constructor used by dynamic creation

// Attributes
public:
  CToolBar toolbar;
  CStatusBar statusbar;
  CDialogBar addressbar;

// Operations
public:

// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CBrowserFrame)
  //}}AFX_VIRTUAL
  virtual void OnUpdateFrameTitle(BOOL);

// Implementation
protected:
  virtual ~CBrowserFrame();

  // Generated message map functions
  //{{AFX_MSG(CBrowserFrame)
  afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
  afx_msg void OnViewAddressBar();
  afx_msg void OnUpdateViewAddressBar(CCmdUI* pCmdUI);
  //}}AFX_MSG
  afx_msg void OnGo();
  afx_msg void OnReset();
  DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BROWSERFRAME_H__5D9F554B_2AFB_11D7_A23A_E0F653C10000__INCLUDED_)
