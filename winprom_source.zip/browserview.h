#if !defined(AFX_BROWSERVIEW_H__5D9F5540_2AFB_11D7_A23A_E0F653C10000__INCLUDED_)
#define AFX_BROWSERVIEW_H__5D9F5540_2AFB_11D7_A23A_E0F653C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BrowserView.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CBrowserView html view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif
#include <afxhtml.h>
#include "winprom.h"
#include "PromDoc.h"
#include "FeatureFmt_dlg.h"
#include "Database.h"


class CBrowserView: public CHtmlView
{
  Feature_fmt title_format;
  Feature *target;
  FT_index target_type;
  GridPoint location;

protected:
  CBrowserView();           // protected constructor used by dynamic creation
  DECLARE_DYNCREATE(CBrowserView)

// html Data
public:
  //{{AFX_DATA(CBrowserView)
    // NOTE: the ClassWizard will add data members here
  //}}AFX_DATA

// Attributes
public:
  CString url;

// Operations
public:
  CPromDoc *GetDocument() const {return (CPromDoc *)CHtmlView::GetDocument();}
  void Navigate(Feature&, FT_index);
  void Navigate(const GridPoint&);
  static void set_format(int, int, int, int);
  void SetViewTitle();

// Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CBrowserView)
  public:
  virtual void OnNavigateComplete2(LPCTSTR strURL);
  protected:
  virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
  virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
  //}}AFX_VIRTUAL

// Implementation
protected:
  virtual ~CBrowserView();
#ifdef _DEBUG
  virtual void AssertValid() const;
  virtual void Dump(CDumpContext& dc) const;
#endif

  // Generated message map functions
  //{{AFX_MSG(CBrowserView)
  afx_msg void OnGoReload();
  afx_msg void OnGoBack();
  afx_msg void OnGoForward();
  afx_msg void OnViewFeature();
  afx_msg void OnGoStop();
  afx_msg void OnUpdateGoStop(CCmdUI* pCmdUI);
  afx_msg void OnOptionsTitle();
  afx_msg void OnOptionsURL();
  afx_msg void OnOptionsOffline();
  afx_msg void OnUpdateOptionsOffline(CCmdUI* pCmdUI);
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BROWSERVIEW_H__5D9F5540_2AFB_11D7_A23A_E0F653C10000__INCLUDED_)
